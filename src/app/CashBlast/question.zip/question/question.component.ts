import { Component, OnInit } from '@angular/core';
import { Socket } from 'ngx-socket-io';
import { CashblastService } from '../services/cashblast.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthService } from 'src/app/auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {
  timeLeft: number = 10;
  
  startmsg:any;
  interval:any;
  players_length: any;
  public QuesAnsList:any;
  public Questions:any;
  percent:number=100;
  player:any;
  isDisabled:boolean;
  isOption:boolean;
  quId:any;
  soundMode: string='play';
  currentUser:any;
  audio: HTMLAudioElement;
  isblast: boolean =false;
  img: any;
  constructor(public router:Router,public auth:AuthService,public service: CashblastService,public socket:Socket,private spinner: NgxSpinnerService) {
   
    this.player=[];
    this.audio = new Audio();
    this.audio.src = 'assets/cashblast/sound/song1.mp3';
    this.audio.load();
    this.audio.play();
    
  }

  ngOnInit() {
    this.isblast=false
    this.player=JSON.parse(localStorage.getItem("players"));
    console.log("players array length ===> "+this.player.length);
    this.players_length = this.player.length;
    this.showNextQuestion();

    this.socket.on("updateLife", (data) => {
  
    this.player=data;
    this.isDisabled=false;
    this.showNextQuestion();

  console.log("Player Updates Life==>"+JSON.stringify(this.player))
 
});
this.socket.on("questionBroadcast", (data) => {
  this.Questions = data.qText;
  this.quId=data.qid
 console.log("questionBroadcast received"+JSON.stringify(data));
});



  }

  showNextQuestion(){
    this.isblast=false;
    this.spinner.show();
    clearInterval(this.interval);
    /** spinner ends after 5 seconds */
    setTimeout(() => {
      this.spinner.hide();
    
        
        this.currentUser = this.auth.getToken();

        
        if(this.player.length==1 ){
          if(this.player.some(item => item.playerName == this.auth.getToken())){
            console.log("Winner");
            
            let data={gameId:this.auth.getInstanceId()};
            this.socket.emit("clearRoom",data);
          setTimeout(() => {
            this.router.navigate(['/dashboard/cashblast/opponent/playquestion/scoreboard'])
          }, 2000); 
          }else{
            
            console.log("Looser")
            let data={gameId:this.auth.getInstanceId()};
            this.socket.emit("clearRoom",data);
            this.router.navigate(['/dashboard/cashblast/cblooser'])
          }
          
        }else{
          console.log(" Player array===> ",JSON.stringify(this.player.indexOf(this.player.find(item => item.playerName == this.auth.getToken()))));
          this.startTimer();
          this.timeLeft= 10;
            
            this.percent=100;
            
          let tempPlayer = this.player[0];
          // console.log("current player position==> ",this.player.find(item => item.index));
          // this.player[0] =  this.player[this.player.indexOf(this.player.find(item => item.playerName == this.auth.getToken()))];
          // this.player[this.player.indexOf(this.player.find(item => item.playerName == this.auth.getToken()))] = tempPlayer;
          // console.log(" new Player array===> ",this.player);
           if(this.player.some(item => item.playerName == this.auth.getToken())){
           
          if(this.player.find(item => item.playerName == this.auth.getToken()).isBomb==true){
            this.isOption=true;
           
            this.getQuestions();
          }else{
            this.isOption=false;
          }
           
         }else{
          console.log("Looser");
          clearInterval(this.interval);
          this.router.navigate(['/dashboard/cashblast/cblooser'])
         }
          
         // console.log("my bomb==<>"+this.player.find(item => item.playerName == this.auth.getToken()).isBomb)
        
        
        }
       
      }, 5000);
   
    
  }

  getMobileNumberMask(mobileNo){
    return mobileNo.substr(0,0)+"XXXXXX"+mobileNo.substr(-4);
    }

  getQuestions() {
    this.isblast = false;
    let endPoint = "getQuestion";
    let requestBody = {
      "gameId": this.auth.getGameId(),
      "packId": this.auth.getPackId()
    }     
    this.service.getQuestion(endPoint, requestBody).then((value) => {
      console.log("questions ans list" + JSON.stringify(value));
      if(value.statusCode == 0 ){
        console.log("Api message "+value.message); 
        this.QuesAnsList = value.data.ansOption;
        this.Questions = value.data.qText;
        this.img = value.qImage;
        this.quId=value.data.qid
        let data={gameId:this.auth.getInstanceId(),question:value.data};
        this.socket.emit("question",data)
     
      }else{
        console.log("Api message "+value.message); 
      
      }
      
    });

  }
  selectedAnsid:any
  getSelectedAns(Ans,index){
    console.log("index is : "+index);
    this.selectedAnsid=index;
    document.getElementById(index).style.backgroundColor = 'skyblue';
    
    
    console.log(index+"<==<Answer is => "+Ans);
    this.submitAns(index);
  }

  submitAns(Answer:any){
    let endPoint = "saveAnswer";
    // let requestBody = {
    //   "qID":"1",
    //   "selectedOption":Answer,
    //   "userId":"1"
    // }

    let requestBody = {
      "qId":this.quId,
      "selectedOption":Answer,
      "uId":this.auth.getUserId(),
      "gameId":this.auth.getGameId(),
      "packId":this.auth.getPackId(),
      "gameInstanceId":this.auth.getInstanceId()
      }
   // this.spinner.show();
   // this.startTimer1();
   // this.timeLeft1 = 5;
    this.service.submitAnswer(endPoint, requestBody).then((value) => {
      console.log("questions ans list" + JSON.stringify(value));
      if(value.statusCode == 0 ){
        console.log("Api message "+value.message); 
        console.log("submit Ans response : "+JSON.stringify(value));
         let correctAnswer = value.data.correctAnswer;
         console.log('correct answer id is : '+correctAnswer);
       // setTimeout(() => {
          /** spinner ends after 5 seconds */
         // this.spinner.hide();
         clearInterval(this.interval);
          document.getElementById(this.selectedAnsid).style.backgroundColor = '#FF5252';
          document.getElementById(correctAnswer).style.backgroundColor = '#5DF971';
     
          this.isDisabled=true;     // }, 5000);
 setTimeout(() => {
 let pl= this.player.filter(item => item.playerName == this.auth.getToken());
     

if(this.selectedAnsid!=correctAnswer){
  pl.find(item => item.playerName == this.auth.getToken()).isBomb=false;
  pl.find(item => item.playerName == this.auth.getToken()).lifeLine -= 1;
  this.isblast = true;
}
     pl= pl[0];
     this.socket.emit("manageLife",pl);
  console.log("current player==>",JSON.stringify(pl))
 }, 2000);
          
      }else{
        console.log("Api message "+value.message); 
      
      }
      
    });
  }
  
//   interval1:any;
//   timeLeft1: number = 5;
//   startTimer1() {
//    this.interval1 = setInterval(() => {
//      if(this.timeLeft1 > 0) {
//        console.log("timer if")
//        this.timeLeft1--;
//        this.percent = this.percent-20;
//      }else{
//       clearInterval(this.interval1);
     
//      }
 
//      console.log("timer")
//    },1000);
 
  
//  }

startTimer() {
  this.isblast = false
  
   this.interval = setInterval(() => {
     if(this.timeLeft > 0) {
     //  console.log("timer if")
       this.timeLeft--;
       this.percent = this.percent-(100/10);
     }else{
      clearInterval(this.interval);
      this.isDisabled=true;
  //    let pl= this.player.filter(item => item.playerName == this.auth.getToken());
      let pl= this.player.filter(item => item.playerName == this.auth.getToken());
      pl.find(item => item.playerName == this.auth.getToken()).isBomb=false;
      pl.find(item => item.playerName == this.auth.getToken()).lifeLine -= 1;
      this.isblast = true;
       pl= pl[0];
       console.log("Player NOt Answer===>"+JSON.stringify(pl))
         this.socket.emit("manageLife",pl);
     
     } 
 
   },1000)

 }
 sound(){
   if(this.audio.volume == 1){
     this.audio.volume =0;
   }else{
    this.audio.volume =1;
   }
 }
 

}

